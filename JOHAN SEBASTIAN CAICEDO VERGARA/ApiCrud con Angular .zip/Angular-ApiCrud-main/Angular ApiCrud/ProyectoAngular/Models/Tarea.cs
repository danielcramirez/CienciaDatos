﻿using System;
using System.Collections.Generic;

namespace ProyectoAngular.Models;

public partial class Tarea
{
    public int IdTarea { get; set; }

    public string? Nombre { get; set; }
}
